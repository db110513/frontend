import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class Joc extends JPanel implements Runnable {

    private int jugadorX = 50;
    private int jugadorY = 50;

    private final double velocitat = 1;

    private boolean nort, sut, est, oest;

    public Joc() {

        // aprofito constructor per crear el Frame
        this.setPreferredSize(new Dimension(500, 500));
        this.setBackground(Color.BLACK);

        addKeyListener(new KeyAdapter() {

            // al pitjar tecla
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    // identificació entre nom variaables (nort sut...) i valor de teclat
                    case KeyEvent.VK_UP: nort = true; break;
                    case KeyEvent.VK_DOWN: sut = true; break;
                    case KeyEvent.VK_LEFT: est = true; break;
                    case KeyEvent.VK_RIGHT: oest = true; break;
                }
            }

            // al deixar tecla
            public void keyReleased(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP: nort = false; break;
                    case KeyEvent.VK_DOWN: sut = false; break;
                    case KeyEvent.VK_LEFT: est = false; break;
                    case KeyEvent.VK_RIGHT: oest = false; break;
                }
            }
        });

        this.setFocusable(true);

    }

    public void run() {
        // Bucle infinit per actualitzar i repintar la posició del quadrat
        while (true) {
            actualitzaJugador();
            // mètode repaint() pertany a la classe JComponent
            repaint();
            try {
                // condiciona la velocitat amb que el quadrat és repintat
                Thread.sleep(6);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void actualitzaJugador() {

        // Actualitzar la posició del jugador segons les fletxes pressionades
        if (nort) jugadorY -= velocitat;  // Moure cap amunt
        if (sut) jugadorY += velocitat;   // Moure cap avall

        if (est) jugadorX -= velocitat;   // Moure a l'esquerra
        if (oest) jugadorX += velocitat;  // Moure a la dreta

        // Mantenir el jugador dins els límits de la finestra
        if (jugadorX < 0) jugadorX = 0;
        if (jugadorY < 0) jugadorY = 0;

        if (jugadorX > getWidth() - 50) jugadorX = getWidth() - 50;
        if (jugadorY > getHeight() - 50) jugadorY = getHeight() - 50;

    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        pintaQuadrat(g);
    }

    private void pintaQuadrat(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(jugadorX, jugadorY, 40, 40);
    }

    public static void main(String[] args) {
        // Crear el panell del joc
        Joc joc = new Joc();

        // Configurar la finestra del joc
        JFrame frame = new JFrame("Joc 2D");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(joc);
        frame.pack();
        frame.setVisible(true);

        // Iniciar el bucle de joc en un nou fil
        new Thread(joc).start();

    }

}
