import java.awt.*;

public class Menjar {
    private int x, y;  // Posició del menjar
    private boolean menjat;  // Estableix si el menjar ja ha estat menjat

    public Menjar(int x, int y) {
        this.x = x;
        this.y = y;
        this.menjat = false;
    }

    public void dibuixaMenjar(Graphics g) {
        if (!menjat) {
            g.setColor(Color.GREEN);  // Color del menjar
            g.fillOval(x, y, 10, 10);  // Dibuixa el menjar com un cercle petit
        }
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 10, 10);  // Retorna el rectangle per la col·lisió
    }

    public boolean isMenjat() {
        return menjat;
    }

    public void setMenjat(boolean menjat) {
        this.menjat = menjat;
    }
}
