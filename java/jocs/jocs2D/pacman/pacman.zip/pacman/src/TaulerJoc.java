import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

public class TaulerJoc extends JPanel implements ActionListener {
    private Pacman pacman;
    private ArrayList<Fantasma> fantasmesList;
    private ArrayList<Menjar> menjarList;
    private boolean tocat;
    private boolean guanyat;  // Nova variable per controlar si s'ha guanyat
    private JButton botoReinicia;

    public TaulerJoc() {
        pacman = new Pacman(this);  // Passant el TaulerJoc com a paràmetre
        fantasmesList = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            fantasmesList.add(new Fantasma(new Random().nextInt(400), new Random().nextInt(400)));
        }

        menjarList = new ArrayList<>();
        // Crear 20 aliments amb posicions aleatòries
        for (int i = 0; i < 20; i++) {
            int x = (int) (Math.random() * (getWidth() - 10));
            int y = (int) (Math.random() * (getHeight() - 10));
            menjarList.add(new Menjar(x, y));
        }

        tocat = false;
        guanyat = false;  // Inicialment no s'ha guanyat

        botoReinicia = new JButton("Reiniciar");
        botoReinicia.setBounds(150, getHeight() / 2 + 30, 100, 50); // Centrat verticalment sota del text
        botoReinicia.setVisible(false);
        botoReinicia.addActionListener(e -> reiniciarJoc());

        // Afegir el botó a un panell de la finestra
        this.setLayout(null);
        this.add(botoReinicia);

        setFocusable(true);

        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                pacman.teclaPitjada(e);
            }
        });
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        setBackground(Color.BLACK);

        if (tocat) {
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 40));
            FontMetrics metrics = g.getFontMetrics();
            String message = "Joc Finalitzat";
            int x = (getWidth() - metrics.stringWidth(message)) / 2;
            int y = getHeight() / 2 - 40;  // Ajusta la posició del text per deixar espai per al botó
            g.drawString(message, x, y);

            // Centrar el botó sota el missatge
            botoReinicia.setBounds((getWidth() - 100) / 2, y + 50, 100, 50);  // Centrat horitzontal i sota del missatge
            botoReinicia.setVisible(true);  // Mostrar el botó per reiniciar el joc
        }
        else if (guanyat) {
            g.setColor(Color.GREEN);  // Color verd per al missatge de guanyador
            g.setFont(new Font("Arial", Font.BOLD, 40));
            FontMetrics metrics = g.getFontMetrics();
            String message = "Has guanyat!";
            int x = (getWidth() - metrics.stringWidth(message)) / 2;
            int y = getHeight() / 2 - 40;  // Ajusta la posició del text per deixar espai per al botó
            g.drawString(message, x, y);

            // Centrar el botó sota el missatge
            botoReinicia.setBounds((getWidth() - 100) / 2, y + 50, 100, 50);  // Centrat horitzontal i sota del missatge
            botoReinicia.setVisible(true);  // Mostrar el botó per reiniciar el joc
        }
        else {
            pacman.dibuixa(g);
            for (Fantasma fantasma : fantasmesList) {
                fantasma.dibuixaFantasma(g);
            }
            for (Menjar menjar : menjarList) {
                menjar.dibuixaMenjar(g);
            }
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (!tocat && !guanyat) {
            pacman.mou();
            for (Fantasma fantasma : fantasmesList) {
                fantasma.moureFantasma();
            }
            checkCollisions();
            repaint();
        }
    }

    private void checkCollisions() {
        Rectangle pacmanBounds = pacman.getBounds();

        // Comprovar col·lisions amb el menjar
        for (Menjar menjar : menjarList) {
            if (!menjar.isMenjat() && pacmanBounds.intersects(menjar.getBounds())) {
                menjar.setMenjat(true);
            }
        }

        // Comprovar col·lisions amb els fantasmes
        for (Fantasma fantasma : fantasmesList) {
            if (pacmanBounds.intersects(fantasma.getBounds())) {
                tocat = true;  // Finalitzar el joc
                break;
            }
        }

        // Finalitzar el joc si Pacman menja tot el menjar
        boolean totMenjat = true;
        for (Menjar menjar : menjarList) {
            if (!menjar.isMenjat()) {
                totMenjat = false;
                break;
            }
        }
        if (totMenjat) {
            guanyat = true;  // Indicar que el jugador ha guanyat
        }
    }

    // Mètode per reiniciar el joc
    private void reiniciarJoc() {
        pacman = new Pacman(this);
        fantasmesList.clear();

        for (int i = 0; i < 8; i++) {  // Crear 8 fantasmes
            fantasmesList.add(new Fantasma(new Random().nextInt(400), new Random().nextInt(400)));
        }

        menjarList.clear();
        // Recrear els aliments amb noves posicions aleatòries
        for (int i = 0; i < 20; i++) {
            int x = (int) (Math.random() * (getWidth() - 10));
            int y = (int) (Math.random() * (getHeight() - 10));
            menjarList.add(new Menjar(x, y));
        }

        tocat = false;
        guanyat = false;
        botoReinicia.setVisible(false);
        repaint();
    }
}
