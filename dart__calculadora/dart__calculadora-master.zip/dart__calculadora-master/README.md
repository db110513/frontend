# CALCULADORA

Calculadora codificada amb Dart fent servir Flutter framework.

Codi compilat:

https://www.loom.com/share/2f9ba45f1c024c9c9edc38ff2ceb46ab
