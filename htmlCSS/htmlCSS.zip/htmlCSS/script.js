document.getElementById('btn').addEventListener('click', function() {
    alert('Has clicat el botó !!');
});
